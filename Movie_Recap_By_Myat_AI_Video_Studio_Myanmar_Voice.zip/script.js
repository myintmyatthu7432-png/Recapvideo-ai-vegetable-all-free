const promptEl=document.getElementById("prompt");
document.querySelectorAll(".prompt-btn").forEach(b=>b.onclick=()=>{promptEl.value=b.dataset.p;promptEl.focus()});

document.getElementById("image").addEventListener("change",e=>{
 const f=e.target.files[0], box=document.getElementById("preview");
 if(!f){box.classList.add("hidden");return}
 const r=new FileReader();
 r.onload=()=>{box.innerHTML=`<img src="${r.result}" alt="Reference image">`;box.classList.remove("hidden")};
 r.readAsDataURL(f);
});

document.getElementById("generate").onclick=()=>{
 const p=promptEl.value.trim();
 const result=document.getElementById("result");
 if(!p){result.textContent="⚠️ အရင်ဆုံး Prompt ရေးပေးပါ။";result.classList.remove("hidden");return}
 const ratio=document.getElementById("ratio").value;
 const duration=document.getElementById("duration").value;
 const style=document.getElementById("style").value;
 result.innerHTML=`<b>✨ Video Prompt Ready</b><br><br>${escapeHtml(p)}<br><br><small>${ratio} · ${duration} · ${style}</small><br><br><span>Demo Mode: Real AI API မချိတ်ရသေးပါ။ Backend/API ချိတ်လိုက်ရင် Generate Video ကို အမှန်တကယ်လုပ်နိုင်ပါပြီ။</span>`;
 result.classList.remove("hidden");
};

document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("light");
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
document.getElementById("split").onclick=()=>{
 const p=promptEl.value.trim(), box=document.getElementById("scenes");
 if(!p){box.innerHTML="<div class='result'>⚠️ Prompt အရင်ရေးပါ။</div>";return}
 const len=Number(document.getElementById("sceneLength").value);
 const count=Math.ceil(60/len);
 box.innerHTML="";
 for(let i=1;i<=count;i++){
   const start=(i-1)*len, end=Math.min(i*len,60);
   const div=document.createElement("div");
   div.className="scene";
   div.innerHTML=`<b>Scene ${i}</b><span>${start}s → ${end}s</span><p>${escapeHtml(p)}</p><small>Voice: ${document.getElementById("voice").value} · Music: ${document.getElementById("music").value}</small>`;
   box.appendChild(div);
 }
};

const voiceSelect=document.getElementById("voiceSelect");
const voiceText=document.getElementById("voiceText");
const voiceNote=document.getElementById("voiceNote");
function loadVoices(){
 if(!("speechSynthesis" in window)) return;
 const voices=speechSynthesis.getVoices();
 voiceSelect.innerHTML='<option value="">Myanmar Voice — Auto</option>';
 voices.filter(v=>/^my|Myanmar/i.test(v.lang)||/Myanmar|Burmese/i.test(v.name))
   .forEach((v,i)=>{const o=document.createElement("option");o.value=v.name;o.textContent=`${v.name} (${v.lang})`;voiceSelect.appendChild(o)});
 if(voiceSelect.options.length===1) voiceNote.textContent="ℹ️ ဒီ Browser/စက်မှာ မြန်မာ TTS voice မတွေ့ရသေးပါ။ Chrome/Android ရဲ့ Text-to-Speech language မှာ Burmese/Myanmar voice ထည့်ပြီး ပြန်ဖွင့်ကြည့်ပါ။";
 else voiceNote.textContent="✅ Myanmar voice တွေ့ပါပြီ။ Play ကိုနှိပ်ပြီး စမ်းနားထောင်နိုင်ပါတယ်။";
}
if("speechSynthesis" in window){loadVoices();speechSynthesis.onvoiceschanged=loadVoices}
document.getElementById("speak").onclick=()=>{
 const text=voiceText.value.trim();
 if(!text){voiceNote.textContent="⚠️ မြန်မာ Script အရင်ထည့်ပါ။";return}
 if(!("speechSynthesis" in window)){voiceNote.textContent="❌ ဒီ Browser မှာ Voice playback မထောက်ပံ့ပါ။";return}
 speechSynthesis.cancel();
 const u=new SpeechSynthesisUtterance(text);
 u.lang="my-MM"; u.rate=Number(document.getElementById("rate").value);
 const wanted=voiceSelect.value;
 const v=speechSynthesis.getVoices().find(x=>x.name===wanted) ||
   speechSynthesis.getVoices().find(x=>/^my/i.test(x.lang));
 if(v) u.voice=v;
 u.onstart=()=>voiceNote.textContent="🔊 မြန်မာ Voice ပြောနေပါတယ်...";
 u.onend=()=>voiceNote.textContent="✅ Voice playback ပြီးပါပြီ။";
 u.onerror=()=>voiceNote.textContent="⚠️ Voice playback မအောင်မြင်ပါ။ Device ရဲ့ TTS language settings ကို စစ်ပါ။";
 speechSynthesis.speak(u);
};
document.getElementById("stopVoice").onclick=()=>{speechSynthesis.cancel();voiceNote.textContent="⏹ Voice ရပ်လိုက်ပါပြီ။"};
