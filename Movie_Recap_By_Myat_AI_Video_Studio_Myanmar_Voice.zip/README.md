# Movie Recap By Myat — AI Video Studio

ဒီ project က AI Video Generator Website ရဲ့ starter frontend ဖြစ်ပါတယ်။

## Run
`index.html` ကို browser နဲ့ဖွင့်ပါ။

## Real AI Video ထုတ်ရန်
Frontend မှာ API key မထည့်ဘဲ ကိုယ်ပိုင် backend တစ်ခုကနေ AI Video API ကို ခေါ်သင့်ပါတယ်။

Architecture:
Frontend → Backend → AI Video API → Video URL → Frontend

API key ကို browser JavaScript ထဲ မထည့်ပါနှင့်။
