const promptEl=document.getElementById("prompt");
document.querySelectorAll(".prompt-btn").forEach(b=>b.onclick=()=>{promptEl.value=b.dataset.p;promptEl.focus()});

document.getElementById("image").addEventListener("change",e=>{
 const f=e.target.files[0], box=document.getElementById("preview");
 if(!f){box.classList.add("hidden");return}
 const r=new FileReader();
 r.onload=()=>{box.innerHTML=`<img src="${r.result}" alt="Reference image">`;box.classList.remove("hidden")};
 r.readAsDataURL(f);
});

document.getElementById("generate").onclick=()=>{
 const p=promptEl.value.trim();
 const result=document.getElementById("result");
 if(!p){result.textContent="⚠️ အရင်ဆုံး Prompt ရေးပေးပါ။";result.classList.remove("hidden");return}
 const ratio=document.getElementById("ratio").value;
 const duration=document.getElementById("duration").value;
 const style=document.getElementById("style").value;
 result.innerHTML=`<b>✨ Video Prompt Ready</b><br><br>${escapeHtml(p)}<br><br><small>${ratio} · ${duration} · ${style}</small><br><br><span>Demo Mode: Real AI API မချိတ်ရသေးပါ။ Backend/API ချိတ်လိုက်ရင် Generate Video ကို အမှန်တကယ်လုပ်နိုင်ပါပြီ။</span>`;
 result.classList.remove("hidden");
};

document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("light");
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
document.getElementById("split").onclick=()=>{
 const p=promptEl.value.trim(), box=document.getElementById("scenes");
 if(!p){box.innerHTML="<div class='result'>⚠️ Prompt အရင်ရေးပါ။</div>";return}
 const len=Number(document.getElementById("sceneLength").value);
 const count=Math.ceil(60/len);
 box.innerHTML="";
 for(let i=1;i<=count;i++){
   const start=(i-1)*len, end=Math.min(i*len,60);
   const div=document.createElement("div");
   div.className="scene";
   div.innerHTML=`<b>Scene ${i}</b><span>${start}s → ${end}s</span><p>${escapeHtml(p)}</p><small>Voice: ${document.getElementById("voice").value} · Music: ${document.getElementById("music").value}</small>`;
   box.appendChild(div);
 }
};
